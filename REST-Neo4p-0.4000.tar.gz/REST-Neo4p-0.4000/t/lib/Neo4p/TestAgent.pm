package Neo4p::TestAgent;

1;

package REST::Neo4p::Agent;
use Mojo::Exception;

sub post_cypher {
  Mojo::Exception->throw('Try this on for size');
}

1;
